-- Runs automatically once, on first container start, because it's mounted
-- into /docker-entrypoint-initdb.d/ in docker-compose.yml. Mirrors what
-- create-databases.bat does for a local (non-Docker) MySQL install.
CREATE DATABASE IF NOT EXISTS auth_service;
CREATE DATABASE IF NOT EXISTS core_banking;
CREATE DATABASE IF NOT EXISTS user_service;
CREATE DATABASE IF NOT EXISTS fund_transfer;
CREATE DATABASE IF NOT EXISTS utility_payment;
