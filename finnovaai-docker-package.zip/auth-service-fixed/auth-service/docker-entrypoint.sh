#!/bin/sh
# If DATABASE_URL is set (Render's standard Postgres connection string,
# format postgres://user:pass@host:port/dbname), convert it into the
# jdbc:postgresql:// form Spring/JDBC actually needs, and split out the
# username/password Spring expects as separate properties.
#
# If DATABASE_URL isn't set (local dev, docker-compose), this whole block
# is skipped and DB_URL/DB_USERNAME/DB_PASSWORD work exactly as before -
# this is a pure addition, nothing existing changes behavior.
if [ -n "$DATABASE_URL" ]; then
    proto_stripped="${DATABASE_URL#*://}"
    userpass="${proto_stripped%%@*}"
    hostportdb="${proto_stripped#*@}"
    export DB_USERNAME="${userpass%%:*}"
    export DB_PASSWORD="${userpass#*:}"
    export DB_URL="jdbc:postgresql://${hostportdb}"
fi

exec java $JAVA_OPTS -jar app.jar
